# JAYA VI JAYA NIRMAN — Premium Website

Clean, premium, single-page website. No build tools needed.

## How to use

1. Open `index.html` in any browser to preview.
2. To put it live for free:

### Option A — Vercel (Recommended)
1. Go to https://vercel.com → Login with GitHub
2. Create a new GitHub repository
3. Upload the `index.html` file
4. Import the repo in Vercel → Deploy
5. Done! You get a free URL.

### Option B — GitHub Pages
1. Create a new repository
2. Upload `index.html`
3. Go to Settings → Pages → Deploy from main branch

## Lead Collection

### WhatsApp
Already working. Floating button + all CTAs open WhatsApp with pre-filled message.

### Email Form
1. Go to https://formspree.io and create a free form
2. Copy your form endpoint
3. In `index.html` find this line:
   ```
   action="https://formspree.io/f/YOUR_FORM_ID"
   ```
4. Replace `YOUR_FORM_ID` with your real ID

## Contact
WhatsApp: +91 73869 46326
